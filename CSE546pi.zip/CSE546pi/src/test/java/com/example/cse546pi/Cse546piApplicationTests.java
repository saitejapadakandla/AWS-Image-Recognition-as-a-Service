package com.example.cse546pi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cse546piApplicationTests {

	@Test
	void contextLoads() {
	}

}
