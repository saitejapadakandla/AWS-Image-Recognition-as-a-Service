package com.example.cse546pi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cse546piApplication {	
	public static void main(String[] args) {
		SpringApplication.run(Cse546piApplication.class, args);
			
	}

}
