package com.example.cse546piListener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Cse546piListenerApplication {
	public static void main(String[] args) {
		SpringApplication.run(Cse546piListenerApplication.class, args);
	}

}