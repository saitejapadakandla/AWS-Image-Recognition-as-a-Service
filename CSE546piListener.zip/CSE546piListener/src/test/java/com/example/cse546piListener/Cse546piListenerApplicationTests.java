package com.example.cse546piListener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cse546piListenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
